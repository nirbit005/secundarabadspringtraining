package SpringMicroserviceProjects.ConsumeServiceSecondClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumeServiceSecondClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumeServiceSecondClientApplication.class, args);
	}

}
