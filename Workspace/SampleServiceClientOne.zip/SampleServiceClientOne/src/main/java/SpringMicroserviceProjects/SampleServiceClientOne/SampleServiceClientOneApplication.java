package SpringMicroserviceProjects.SampleServiceClientOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleServiceClientOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleServiceClientOneApplication.class, args);
	}

}
